package com.concessionaria.BackConcessionaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackConcessionariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
