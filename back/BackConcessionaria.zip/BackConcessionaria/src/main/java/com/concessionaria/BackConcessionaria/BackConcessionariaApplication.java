package com.concessionaria.BackConcessionaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackConcessionariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackConcessionariaApplication.class, args);
	}

}
